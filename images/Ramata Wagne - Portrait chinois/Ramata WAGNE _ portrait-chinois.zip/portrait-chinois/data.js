var analogies = ["Une couleur", "Un animal", "Un pays", "Une célébrité", "Un sport", "Un film", "Une musique"];

var valeursAnalogies = [
  "Si j étais une couleur je serai la couleur violette parce c est une couleur que j aime et qui represente une partie de ma personnalité. En effet la couleur violette represente la créativité et la sagesse et je me retrouve dans ces dires. ",

  "Si j etais un animal je serai un chat parce que c est tout simplement mon animal préféré. Cet animal incarne l independance et la libérte mais au delà de ça c est un animal câlin et trés joueur malgré ce qu on peut croire ",

  "Si j etais un pays je serai le Sénégal, pas besoin de chercher trop loin mon origine. Le Sénégal est un pays rempli d un patrimoine historique lourd mais trés intéressant à connaître. En parlant en profondeur du pays, les habitants du pays de la Teranga sont d une hospitalité et d une gentillesse inconditionnel, ils serton toujours à votre disposition pour vous aider en cas de probléme. Ils ont cet âme de solidarité depuis toujours.",

  "Si j étais une célébrité je serai Rihanna parce que c est une femme qui est indépendante, elle a su ce demarquer avec sa personnalité tranchante et extravagante. Ce que j'admire le plus chez elle, c est ça confiance en elle, c est un trait de caractère chez elle que j aime beaucoup et que j aimerai mettre en evidende pour ma personne. ",

  "Si j etais un sport je serai la danse. La danse est pour depuis toute petite un moyen d exprimer mes emotions, j ai une facilité a transmettre mes émotionsn avec mon corps. Le style de danse que je cible est le Hip-Hop, étant un style de danse qui en regroupe d autre il y a de quoi bien s exprimer avec. La danse est pour moi une passion que je veux faire perdurer dans ma vie encore et encore. ",

  "Si j etais un film je serai The Truman Show. Ce film refléte une volonté de comprendre les différentes couches de réalité et de perception qui entourent mon existence. En effet ce film illustre bien le fait que je suis consciente du regards ou même des attentes des autres dans ma vie ce qui fait que je me sens observé par le monde et même parfois influencé par ce que je vois.",

  "Si  j étais une musique je serai Rehab de Rihanna. Oui on peut voir que j aime beaucoup Rihanna et ce n est pas pour rien. Rehab parle d une personne qui est attirée par une relation toxique mais qui se rend compte que cette relation est destructrice. Bien que je n ai heuresement jamais connue cette situation, cette musique au niveau de sa sonorité et ses paroles me plonge dans mood spécial."
];

var images = [
  "violet.jpeg",
  "chat.jpeg",
  "senegall.jpeg",
  "rihanna.jpeg",
  "hiphop.jpeg",
  "trumanshow.jpeg",
  "rehab.jpeg"
];

var rarou = [
  "violet2.jpeg",
  "chat.jpeg",
  "senega.jpg",
  "rihanna.jpeg",
  "hiphop.jpeg",
  "trumanshow.jpeg",
  "rehab.jpeg"
];


